[t,x] = ode45(@OPAMPs,[0 2], [0 0]);
figure(1)
plot(t,x(:,1),'b', LineWidth=1.5);
grid on
title("V de salida");
xlabel("Tiempo");
ylabel("Volts");  
